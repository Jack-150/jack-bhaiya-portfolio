import "./styles/About.css";
const About = () => <div className="about-section" id="about"><div className="about-me"><h3 className="title">About Me</h3><p className="para">I'm Jack Bhaiya, a creative Video Editor and Content Creator passionate about turning raw footage into engaging visual content. I specialize in Gaming Edits, YouTube Shorts, Roast Edits and high-energy short-form videos using CapCut and Adobe Premiere Pro.</p></div></div>;
export default About;
