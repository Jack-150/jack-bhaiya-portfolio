import { PropsWithChildren } from "react";
import "./styles/Landing.css";

const Landing = ({ children }: PropsWithChildren) => (
  <div className="landing-section" id="landingDiv"><div className="landing-container">
    <div className="landing-intro"><h2>Hello! I'm</h2><h1>JACK<br/><span>BHAIYA</span></h1></div>
    <div className="landing-info"><h3>A Creative</h3><h2 className="landing-info-h2"><div className="landing-h2-1">Video</div><div className="landing-h2-2">Editor</div></h2><h2><div className="landing-h2-info">Content</div><div className="landing-h2-info-1">Creator</div></h2></div>
  </div>{children}</div>
);
export default Landing;
